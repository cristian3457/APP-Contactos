package com.jaod.contactos;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;
import android.widget.Toast;


public class principalActivity extends AppCompatActivity {

    private  ArrayAdapter<String> adaptador;
    private ListView lvContactos;
    public static ArrayList<String> datos=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.principal);
        MainActivity M = new MainActivity();
        if(M.nombre.toString().length()>0 & M.email.toString().length()>0){
            datos.add("Usuario:"+M.nombre.toString()+"    "+"Email:"+M.email.toString());
            Toast toast = Toast.makeText(principalActivity.this,"EL CONTACTO SE AGREGO CORRECTAMENTE AL LISTVIEW", Toast.LENGTH_LONG);
            toast.show();
        }

        adaptador = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, datos);
        lvContactos=(ListView)findViewById(R.id.lvContactos);
        lvContactos.setAdapter(adaptador);
        adaptador.notifyDataSetChanged();
    }
    public void Agregar(View view){
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
    }
}
