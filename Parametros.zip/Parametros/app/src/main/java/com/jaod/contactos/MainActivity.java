package com.jaod.contactos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText txtnombre;
    private EditText txtemail;
    private EditText txttwitter;
    private EditText txttel;
    private EditText txtdate;
    public String entro="no";
    public static String nombre="";
    public static String email="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtnombre = (EditText)findViewById(R.id.txtnombre);
        txtemail = (EditText)findViewById(R.id.txtemail);
        txttwitter = (EditText)findViewById(R.id.txttwitter);
        txttel= (EditText)findViewById(R.id.txttel);
        txtdate = (EditText)findViewById(R.id.txtdate);

    }

    public void Guardar (View view){
        Intent i = new Intent(this, principalActivity.class);
        nombre=txtnombre.getText().toString();
        email=txtemail.getText().toString();
        if(nombre.toString().length()>0 & email.toString().length()>0){
            i.putExtra("dato",txtnombre.getText().toString());
            //startActivity(i);
            i.putExtra("dato1",txtemail.getText().toString());
            startActivity(i);

        }else{
            Toast toast = Toast.makeText(MainActivity.this, "PARA QUE SE AGREGUE EL CONTACTO Y SE MUESTRE EN EL LISTVIEW TIENES QUE LLENAR " +
                    "POR LO MENOS LOS CAMPOS DE USUARIO Y DE EMAIL", Toast.LENGTH_LONG);
            toast.show();
        }

    }
    public void Regresar(View view){
        Intent i = new Intent(this, principalActivity.class);
        startActivity(i);
        nombre="";
        email="";
    }
}
